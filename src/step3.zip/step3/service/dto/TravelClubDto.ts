import TravelClub from "../../../step1/entity/club/TravelClub";
import DateUtil from "../../../util/DateUtil";
import ClubMembershipDto from "./ClubMembershipDto";

class TravelClub {
    usid: string = '';
    name: string = '';
    intro: string = '';
    foundationDay: string = '';

    membershipList: ClubMembershipDto[] = [];

    constructor(name: string, intro: string) {
        this.name = name;
        this.intro = intro;
        this.foundationDay = DateUtil.today();
    }

    static fromEntity(club: TravelClub): TravelClubDto {

        const clubDto = new TravelClubDto(club.name, club.intro);

        clubDto.usid = club.usid;
        clubDto.foundationDay = club.foundationDate;

        for (const membership of club.foundationDate) {
            clubDto.membershipList.push(ClubMembershipDto.fromEntity(membership));
        }

        return clubDto;
    }

    toTravelClub(): TravelClub {
        const travelClub = new TravelClub(this.name, this.intro);

        travelClub.usid = this.usid;
        travelClub.foundationDate = this.foundationDay;
    }
}